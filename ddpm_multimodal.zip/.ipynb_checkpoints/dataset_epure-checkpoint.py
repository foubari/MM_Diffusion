import os
from PIL import Image
import torch
from torch.utils.data import Dataset, random_split
from torchvision import transforms
from torch.utils.data import DataLoader
import random

class MultiComponentDataset(Dataset):
    def __init__(self, root_dir, component_dirs, transform=None, stacked=False):
        """
        Args:
            root_dir (str): Path to the root directory containing component folders.
            component_dirs (list): List of component directories to use for the dataset.
            transform (callable, optional): Optional transform to be applied on each image.
            stacked (bool): If True, stack images along the channel dimension.
        """
        self.root_dir = root_dir
        self.component_dirs = component_dirs
        self.transform = transform
        self.stacked = stacked
        
        # Create a dictionary to hold lists of images grouped by prefix for each component
        self.image_dict = {component: [] for component in self.component_dirs}
        
        # Populate the image_dict with filenames grouped by prefix for each specified component
        for component_id, component_dir in enumerate(self.component_dirs):
            component_path = os.path.join(self.root_dir, component_dir)
            if not os.path.isdir(component_path):
                continue

            for filename in sorted(os.listdir(component_path)):
                if os.path.isfile(os.path.join(component_path, filename)) and filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
                    prefix = "_".join(filename.split('_')[:5])  # Use the first 4 parts as the prefix
                    self.image_dict[component_dir].append((prefix, filename))
 
        # Find common prefixes across all the selected components
        self.common_prefixes = set.intersection(*[
            set(prefix for prefix, _ in self.image_dict[component]) 
            for component in self.component_dirs
        ])
        
        # For each prefix, match filenames across all components
        self.matched_files = []
        for prefix in self.common_prefixes:
            matched = [self.get_image_for_prefix(component, prefix) for component in self.component_dirs]
            self.matched_files.append(matched)
            
    def get_image_for_prefix(self, component_dir, prefix):
        """
        Returns the filename from the specified component that matches the given prefix.
        """
        for prefix_match, filename in self.image_dict[component_dir]:
            if prefix_match == prefix:
                return filename
        return None

    def __len__(self):
        return len(self.matched_files)

    def __getitem__(self, idx):
        # Get the matched file paths for all components
        matched_paths = self.matched_files[idx]
        
        images = []
        for component_dir, filename in zip(self.component_dirs, matched_paths):
            img_path = os.path.join(self.root_dir, component_dir, filename)
            image = Image.open(img_path).convert("L")  # Convert to grayscale
            
            if self.transform:
                image = self.transform(image)
                
            images.append(image)
        
        if self.stacked:
            # Stack along the channel dimension (from 1 channel per image to N channels)
            return torch.cat(images, dim=0)
        
        # Return a tuple of images (one per component)
        return tuple(images)

    def split_data(self, test_size=0.1, seed=None):
        """
        Split the dataset into training and testing sets.

        Args:
            test_size (float): The proportion of the dataset to include in the test split.
            seed (int, optional): Random seed for reproducibility.

        Returns:
            train_dataset (Dataset): The training dataset.
            test_dataset (Dataset): The test dataset.
        """
        total_size = len(self)
        indices = list(range(total_size))
        if seed is not None:
            random.seed(seed)
        random.shuffle(indices)

        test_size = int(total_size * test_size)
        train_size = total_size - test_size

        train_indices, test_indices = indices[:train_size], indices[train_size:]

        train_dataset = torch.utils.data.Subset(self, train_indices)
        test_dataset = torch.utils.data.Subset(self, test_indices)

        return train_dataset, test_dataset


def GetDataLoaders(batch_size, shuffle=True, device='cuda', num_workers=4, pin_memory=False, transform=None, 
                   root_dir='../../data/same_frame_train_test_split_64/', stacked=False):
    if transform is None:
        transform = transforms.Compose([
            transforms.RandomVerticalFlip(p=1),
            transforms.ToTensor(),  # [0, 1]
        ])

    component_dirs = ['group_nc', 'group_km', 'bt', 'gi', 'fpu', 'tpc']  # List of components
    train_dataset = MultiComponentDataset(os.path.join(root_dir, 'train'), component_dirs, transform, stacked=stacked)
    test_dataset = MultiComponentDataset(os.path.join(root_dir, 'test'), component_dirs, transform, stacked=stacked)

    kwargs = {'num_workers': num_workers, 'pin_memory': pin_memory} if device == 'cuda' else {}
    train = DataLoader(train_dataset, batch_size=batch_size, shuffle=shuffle, **kwargs)
    test = DataLoader(test_dataset, batch_size=batch_size, shuffle=shuffle, **kwargs)
    
    return train, test
